
<!DOCTYPE html>
<html>
<body>
<form method="post" action="handle_upload.php" enctype="multipart/form-data">
    <label>File:</label>
    <input type="file" name="file" required>
    <button type="submit">Upload</button>
</form>
</body>
</html>
